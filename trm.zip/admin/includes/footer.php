<div class="copyrights">
	 <p>Presented By  |  phptraining.com </p>
</div>	
